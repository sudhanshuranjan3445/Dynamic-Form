<?php
include "dbconnection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $contact = $_POST['contact'];

    $sql = "INSERT INTO userinformationform (name, age, contact) 
            VALUES ('$name', '$age', '$contact')";

    if (mysqli_query($conn, $sql)) {
        // ✅ Successfully inserted, now redirect to fetch.php
        header("Location: fetch.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>

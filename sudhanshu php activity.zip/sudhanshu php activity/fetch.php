<?php
include "dbconnection.php";

// fetch query
$sql = "SELECT `name`, `age`, `contact` FROM userinformationform";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Details Table</title>
</head>
<body>
  <div>
    <h1>All User Details</h1>
    <table border="1" cellpadding="8" cellspacing="0">
      <thead>
        <tr>
          <th>Name</th>
          <th>Age</th>
          <th>Contact</th>
      </thead>
      <tbody>
        <?php
        if(mysqli_num_rows($result) > 0){
          while($row = mysqli_fetch_assoc($result)){
            echo "<tr>
              <td>".$row['name']."</td>
              <td>".$row['age']."</td>
              <td>".$row['contact']."</td>
            </tr>";
          }
        } else {
          echo "<tr><td colspan='6'>No records found</td></tr>";
        }
        ?>
      </tbody>
    </table>

    <!-- Back Button -->
    <a href="index.php">
      <button>⬅ Back to Form</button>
    </a>
  </div>
</body>
</html>

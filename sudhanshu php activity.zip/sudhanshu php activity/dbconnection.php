<?php
// DBCONNECTION.PHP

$conn = mysqli_connect("localhost", "root", "", "phpactivity", 3306);

if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
}
?>

<?php
// index.php
include "dbconnection.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Advanced User Form</title>
</head>
<body>
  <div class="container">
    <h1>User Information Form</h1>
    <form action="insert.php" method="POST">
      <label for="name">Name:
        <input type="text" id="name" name="name" placeholder="Your full name" required>
      </label>
      <br><br>
      <label for="age">Age:
        <input type="number" id="age" name="age" min="0" max="120" required>
      </label>
      <br><br>
      <label for="contact">Contact (Phone):
        <input type="tel" id="contact" name="contact" pattern="[0-9]{10}" placeholder="1234567890" required>
      </label>
      <br><br>
      <div>
        <button type="submit">Submit</button>
        <a href="fetch.php">View Records</a>
      </div>
    </form>
  </div>
</body>
</html>
